export const mergeClasses = (classes: string[]) => {
    return classes.join(' ')
}
